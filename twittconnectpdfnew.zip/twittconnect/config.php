<?php
define('CONSUMER_KEY', 'mbvMNSr6aOkCUoAp7BsnxYFh5');
define('CONSUMER_SECRET', 'U61CfZgQvJEkCRyItvrympGJiLTtEsostukgnPErdH9AB9Pm04');
define('OAUTH_CALLBACK', 'http://work.zestard.com/twittconnect/process.php');
?>