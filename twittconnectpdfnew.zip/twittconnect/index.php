<?php
//start session
session_start();

// Include config file and twitter PHP Library by Abraham Williams (abraham@abrah.am)
include_once("config.php");
include_once("inc/twitteroauth.php");

?>
<!DOCTYPE html>
<html>
<head>
    <title>Twitt Connect</title>
    <link rel="stylesheet" type="text/css" href="/twittconnect/assets/css/header.css">
</head>
<body>
<?php
require_once('head.php');
require_once('login.php');
?>
</body>
</html>