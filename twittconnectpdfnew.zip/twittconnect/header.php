<div class="main-header-container">
    <div class="main-logo"><a href="home.php"><img src="/twittconnect/assets/images/logo_head.png"><span class="title-main">Twitter Connect</span></a></div>
</div>