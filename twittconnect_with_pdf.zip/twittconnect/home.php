<?php
session_start();
include_once("config.php");
include_once("inc/twitteroauth.php");
include_once("includes/functions.php");
include("lib/mpdf/MPDF57/mpdf.php");

    if(isset($_SESSION['status']) && $_SESSION['status'] == 'verified')
    {
        //Retrive variables
        $screen_name        = $_SESSION['request_vars']['screen_name'];
        $twitter_id         = $_SESSION['request_vars']['user_id'];
        $oauth_token        = $_SESSION['request_vars']['oauth_token'];
        $oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];
        $htmlslider         = '';

        $connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);

        //Get latest tweets
        $my_tweets = $connection->get('statuses/user_timeline', array('screen_name' => $screen_name, 'count' => 10));

         //If user wants to tweet using form.
        if(isset($_POST["dwntwt"]))
        {
            $num = 0;
            // $dtwt = array();
            if($my_tweets) {
                $pdfdata = '<h2 align="center">Latest Tweets(Max. 10)</h2>';
                $pdfdata .= '<table style="border: 2px solid black;">';
                $pdfdata .='<thead style="font-size: 20px;">';
                $pdfdata .='<tr>';
                $pdfdata .= '<th>Tweets</td>';
                $pdfdata .= '<th>Created Date & Time</td>';
                $pdfdata .='</tr>';
                $pdfdata .='</thead>';
                $pdfdata .='<tbody>';
                 foreach ($my_tweets  as $my_tweet) {

                     $pdfdata .='<tr>';
                     $pdfdata .= '<td style=" border: 1px solid;">' . $my_tweet->text . '</td>';
                     $pdfdata .= '<td style=" border: 1px solid;">' . $my_tweet->created_at . '</td>';
                     $pdfdata .='</tr>';
                }
                $pdfdata .='</tbody>';
                $pdfdata .= '</table>';
             }
            $mpdf = new mPDF('c','A4','','' , 12.7, 12.7, 14, 12.7, 8, 8);
            $mpdf->WriteHTML($pdfdata);
            // $mpdf->Output();
            $mpdf->Output('twitt.pdf', 'I');
        }
        echo '<!DOCTYPE html><html><head><title>Twitter Connect</title></head><body>
        ';
        //Show welcome message
        echo '<div class="welcome_txt">Welcome <strong>'.$screen_name.'</strong> (Twitter ID : '.$twitter_id.'). <a href="logout.php?logout">Logout</a>!</div>';

        include('header.php') ;


        $htmlslider .= '<div class="twitter-posts">';
        $htmlslider .= '<div class="post-title"><h3> Latest Posts(Max. 10)</h3><form action="" method="post"><input type="submit" class="dwntwt-btn followers-data" name="dwntwt" id="dwntwt" value="Download Your Twits"></form></div>';
        $htmlslider .= '<div class="container"><br><div id="myCarousel" class="carousel slide" data-ride="carousel"><ol class="carousel-indicators"><li data-target="#myCarousel" data-slide-to="0" class="active"></li><li data-target="#myCarousel" data-slide-to="1"></li><li data-target="#myCarousel" data-slide-to="2"></li><li data-target="#myCarousel" data-slide-to="3"></li></ol>';



        $htmlslider .= '<div class="carousel-inner" role="listbox">';
        $i = 0;
        foreach ($my_tweets  as $my_tweet) {
            if ($i == 0)
            {
                $htmlslider .= '<div class="item active">';
            }
            else
            {
                $htmlslider .= '<div class="item">';
            }
            $htmlslider .= '<div class="twittitem">'.$my_tweet->text.' <br />-<i>'.$my_tweet->created_at.'</i></div>';
            $htmlslider .= '</div>';
            $i++;
        }
        $htmlslider .= '</div>';



        // Left and right controls
        $htmlslider .= '<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="right carousel-control" href="#myCarousel" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><span class="sr-only">Next</span></a></div></div>';
        $htmlslider .= '</div>';

        echo $htmlslider ;


        $followers = $connection->get('followers/list', array('screen_name' => $screen_name, 'count' => 10000));
        $allusers = array();
        $flcounts = 0;
        foreach ($followers->users as  $allfl) {
            $allusers[$flcounts]['scrname'] = $allfl->screen_name;
            $allusers[$flcounts]['id'] = $allfl->id;
            $allusers[$flcounts]['name'] = $allfl->name;
            $flcounts++;
        }

        $followerslider = '';
        $followerslider .= '<div class="followers-container">';
        $followerslider .= '<div class="followers-title post-title"><h3>Followers</h3></div>';
        $followerslider .= '<div class="followers-search-box"><label>Search follower</label> <input type="text" name="searchfl" id="searchfl" placeholder="Search Followers"><span> Search max. 10 followers</span></div>';
        $followerslider .= '<div class="followers-list">';
        $follow = (array)$followers->users;

        if (count($follow) > 0)
        {
           if (count($follow) >= 10 ) {
               $flrand = array_rand($follow, 10);
           }
           else
           {
                $flrand = array_rand($follow, count($follow));
           }

            foreach ($flrand as  $fl) {
                $followerslider .= '<div class="followers-data">';
                $followerslider .= '<span class="follower"  data-scr="' . $follow[$fl]->screen_name . '""data-id="' . $follow[$fl]->id . '">' . $follow[$fl]->name . '</span>';
                $followerslider .= '</div>';
            }
        }


        $followerslider .= '</div>';
        $followerslider .= '</div>';
        echo $followerslider;
        include('footer.php');
    }
    else{
        header('Location: index.php');
    }
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="/twittconnect/assets/css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/twittconnect/assets/js/twitterflw.js"></script>
<style>
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  width: 70%;
  margin: auto;
}
.carousel-inner > .item{ height: 300px; margin: 4% 0 0 10%;}
.twittitem { width="460"; height="345"; }
</style>
<script type="text/javascript">
$(document).ready(function(){
    $(document).on('click', '.follower', function(){
        var followerid = $(this).attr('data-id');
        var followerscr = $(this).attr('data-scr');
        var url = "/twittconnect/helper/followerstwitt.php";
        $.ajax({
                    url: url,
                    type: "post",
                    data: {'fid':followerid, 'scr': followerscr},
                    success: function(data){
                        data;
                        $('.twitter-posts').html(data);
                    }
                });
    });
    var allusers = '<?php echo json_encode($allusers); ?>';
    var fldiv = $('.followers-list').html();
    $('#searchfl').on('keyup', function(){
        var searchval = $(this).val();
        var users = JSON.parse(allusers);
        var followerslidersearch = '';
        if(searchval){
            searchval = searchval.toLowerCase();
            var setusercount = 0;
            for (i = 0; i < users.length;i++)
            {
                if (users[i].name.toLowerCase().indexOf(searchval) >= 0 )
                {
                    followerslidersearch += '<div class="followers-data">';
                    followerslidersearch += '<span class="follower"  data-scr="' + users[i].scrname + '""data-id="' + users[i].id + '">' + users[i].name + '</span>';
                    followerslidersearch += '</div>';
                    setusercount++;
                }
                if (setusercount==10) {
                    break;
                }
            }
            $('.followers-list').html(followerslidersearch);
        }
        else
        {
            $('.followers-list').html(fldiv);
        }

    });
});

</script>