<div class="login-head">
    <h4>Please Login</h4>
    <div class="login-form">
        <div class="login-user">
            <a href="process.php"><img src="assets/images/sign-in-with-twitter.png" width="151" height="24" border="0" /></a>
        </div>
    </div>
    <div class="login-notice"><p>Note : Use twitter login/password for authentication.</p></div>
</div>
