<div class="top-heading">
    <div class="top-logo-head">
        <?php $logoPath = '/twittconnect/assets/images/logo_head.png'; ?>
        <a href=""><img src="<?php echo $logoPath; ?>"></a>
        <h2>Twitter Connect</h2>
    </div>
</div>