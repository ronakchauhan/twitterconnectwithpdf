// $(document).on('click', '.follower', function(){
//     var followerid = $(this).attr('data-id');
// });