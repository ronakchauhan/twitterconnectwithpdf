<?php
include("../config.php");
include("../inc/twitteroauth.php");
include("../includes/functions.php");
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<?php
$oauth_token        = $_SESSION['request_vars']['oauth_token'];
$oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];

$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);

$fid = $_POST['fid'];
$fscr= $_POST['scr'];
$fl_tweets = $connection->get('statuses/user_timeline', array('screen_name' => $fscr,'count' => 10));
$tottwitts = count($fl_tweets);
$flhtmlslider .= '<div class="post-title"><h3> Latest '.  $tottwitts . ' Post(s) - ' . $fscr . '(Max. 10)</h3></div>';
        $flhtmlslider .= '<div class="container"><br><div id="myCarousel" class="carousel slide" data-ride="carousel"><ol class="carousel-indicators"><li data-target="#myCarousel" data-slide-to="0" class="active"></li><li data-target="#myCarousel" data-slide-to="1"></li><li data-target="#myCarousel" data-slide-to="2"></li><li data-target="#myCarousel" data-slide-to="3"></li></ol>';


        $flhtmlslider .= '<div class="carousel-inner" role="listbox">';
        $i = 0;
        foreach ($fl_tweets  as $fl_tweets) {
            if ($i == 0)
            {
                $flhtmlslider .= '<div class="item active">';
            }
            else
            {
                $flhtmlslider .= '<div class="item">';
            }

            $flhtmlslider .= '<div class="twittitem">'.$fl_tweets->text.' <br />-<i>'.$fl_tweets->created_at.'</i></div>';
            $flhtmlslider .= '</div>';
            $i++;
        }
        if ($i == 0)
        {
            $flhtmlslider .= '<div class="item active">';
            $flhtmlslider .= '<div class="twittitem">No Twitts yet</div>';
            $flhtmlslider .= '</div>';
        }
        $flhtmlslider .= '</div>';

        // Left and right controls
        $flhtmlslider .= '<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="right carousel-control" href="#myCarousel" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span><span class="sr-only">Next</span></a></div></div>';

        echo $flhtmlslider;exit;