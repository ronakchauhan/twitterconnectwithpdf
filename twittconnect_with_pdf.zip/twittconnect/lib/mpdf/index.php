<?php

$myfile = fopen("result.txt", "w") or die("Unable to open file!");
$tax = 10;
$txt = "<span style='color:red;'>Name</span> : John Doe<br>";
$txt .= "Age : " . ((int)('100.00') + $tax);
fwrite($myfile, $txt);
fclose($myfile);


include("MPDF57/mpdf.php");
$mpdf = new mPDF('c','A4','','' , 12.7, 12.7, 14, 12.7, 8, 8);
$mpdf->SetDisplayMode('fullpage');
$mpdf->list_indent_first_level = 0;  // 1 or 0 - whether to indent the first level of a list
//$mpdf->SetJS('this.print();');

//$html = file_get_contents('invoice.html');
$html = file_get_contents('result.txt');

$mpdf->WriteHTML($html);
//$mpdf->Output();
$mpdf->Output('download.pdf', 'I');